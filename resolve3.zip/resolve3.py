print('Задание "Длина строки"')
print(len('Длина строки'))
print('Задание "Суммы и разности"')
first = 15
second = 17
print(15+17)
print(15-17)
summa = 32
diff = -2
print(summa)
print(diff)
print('Задание "Среднее арифметическое"')
first = 17
second = 15  # не пойму, почему идет подчеркивание синтаксиса? ошибка????
third = 3
print((17+15+3)/3)
mean = 11.666666666666666
print(mean)
print('Задание "Простые строчки"')
First_string = "Вторник"
Second_string = "Понедельник"
print(Second_string,',',' ',First_string)

print('Задача "Сложная формула"')
a = 3
b = 5
c = 7
print((a*b)+(a*c))
f = 36
print((f**3)/2)



