print(20//10) # // - целочисленное деление, / - просто деление
print(type(5))  # мой комментарий
print(5 % 5)
print(5 ** 2)
print(type(2.0))
print(2.0 + 3.33)
print('"Hello, world!"') # этот принцип можно использовать для цитат русского языка
print(type('Hello world!')) # string - строка
print('Hello,' + '   world!')
print('1+''1 = 2')
print(type(True), type(False)) # boolean логический тип данных
print(5>10, 10>5)
print(1, 2, 5, 'Hello!', True)
print(5>=5)
print(5!=5)
print(5!=5 and 5<10)
print(5!=5 or 5<10)
print(int('5'))