print("Hello world")
print("test")
print("Привет Александр")
